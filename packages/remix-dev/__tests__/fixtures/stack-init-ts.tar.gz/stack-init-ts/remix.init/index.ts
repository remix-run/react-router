// this is the init file

const run = ({rootDirectory}: {rootDirectory: string}) => {
    console.log(`Running init script on ${rootDirectory}`);
}

export default run;
