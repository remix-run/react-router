module.exports = {
  extends: ["@remix-run/eslint-config"],
};
