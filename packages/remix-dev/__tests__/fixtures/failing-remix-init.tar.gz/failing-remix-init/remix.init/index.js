module.exports = () => {
  throw new Error("💣");
};
