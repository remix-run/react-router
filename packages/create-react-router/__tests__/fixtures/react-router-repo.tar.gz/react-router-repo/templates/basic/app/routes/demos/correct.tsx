export default function NiceWork() {
  return <h1>You got it right!</h1>;
}
